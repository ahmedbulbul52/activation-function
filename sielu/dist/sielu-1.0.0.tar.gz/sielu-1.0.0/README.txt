This is an activation function can be used in deep learning model development.
